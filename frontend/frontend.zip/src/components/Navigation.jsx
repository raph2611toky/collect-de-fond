"use client"

import { useLanguage } from "../context/LanguageContext"
import "../styles/Navigation.css"
import { useTheme } from "../context/ThemeContext"

const translations = {
  mg: {
    home: "Tahiry",
    create: "Lumikra",
    profile: "Profil",
  },
  fr: {
    home: "Accueil",
    create: "Créer",
    profile: "Profil",
  },
  en: {
    home: "Home",
    create: "Create",
    profile: "Profile",
  },
}

export default function Navigation({ currentPage, setCurrentPage, translations: navTranslations }) {
  const { language } = useLanguage()
  const t = navTranslations || translations[language]
  const { isDark, toggleTheme } = useTheme()

  const navItems = [
    { id: "home", label: t.home, icon: "📋" },
    { id: "create", label: t.create, icon: "✨" },
    // { id: "profile", label: t.profile, icon: "👤" },
  ]

  return (
    <nav className={`navigation ${isDark ? 'dark-mode' : ''}`}>
      <div className={`nav-container ${isDark ? 'dark-mode' : ''}`}>
        {navItems.map((item) => (
          <button
            key={item.id}
            className={`nav-item ${currentPage === item.id ? "active" : ""}`}
            onClick={() => setCurrentPage(item.id)}
          >
            <span className="nav-icon">{item.icon}</span>
            <span className="nav-label">{item.label}</span>
          </button>
        ))}
      </div>
    </nav>
  )
}
