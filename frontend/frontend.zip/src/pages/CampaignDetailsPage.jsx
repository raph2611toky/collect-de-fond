"use client"

import { useParams, useNavigate } from "react-router-dom"
import { useState } from "react"
import { useTheme } from "../context/ThemeContext"
import { useLanguage } from "../context/LanguageContext"
import RichTextEditor from "../components/RichTextEditor"
import "../styles/CampaignDetails-cotizup.css"

export default function CampaignDetailsPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { isDark } = useTheme()
  const { language } = useLanguage()
  const [updates, setUpdates] = useState([
    {
      id: 1,
      author: "Jean Durand",
      date: "23 févr. 2025",
      content: "Merci beaucoup pour votre soutien ! Nous avons atteint 80% de notre objectif.",
      type: "text",
    },
    {
      id: 2,
      author: "Jean Durand",
      date: "20 févr. 2025",
      content: "https://www.youtube.com/embed/dQw4w9WgXcQ",
      type: "video",
    },
  ])

  const [newUpdate, setNewUpdate] = useState("")
  const [showUpdateForm, setShowUpdateForm] = useState(false)

  const translations = {
    fr: {
      why: "Pourquoi ?",
      updates: "Actualités",
      participants: "Participants",
      share: "Mobilisez du monde ! Votre soutien passe aussi par le partage :",
      share_facebook: "Partager sur Facebook",
      share_twitter: "sur Twitter",
      share_email: "par Email",
      copy_link: "Copier le lien :",
      copied: "Copié !",
      donate_btn: "Donner maintenant",
      raised: "collectés avec",
      donors: "participants",
      closed: "Cagnotte clôturée",
      closed_date: "Fermée depuis le 26 février 2025",
      platform_secure: "Plateforme 100% sécurisée",
      created_by: "par",
      add_update: "Ajouter une actualité",
      post_update: "Publier",
      cancel: "Annuler",
      anonymous: "Anonyme",
      private: "PRIVE",
    },
    mg: {
      why: "Inona?",
      updates: "Vaovao",
      participants: "Roangondry",
      share: "Mobilisez mpiara-maso ! Ny fanampiana dia kakaisan:",
      share_facebook: "Ibahagi sa Facebook",
      share_twitter: "sa Twitter",
      share_email: "sa Email",
      copy_link: "Kopy ny link:",
      copied: "Nokopyana!",
      donate_btn: "Manao fampidirana ankehitriny",
      raised: "nakolekta miaraka amin'ny",
      donors: "roangondry",
      closed: "Cagnotte clôturée",
      closed_date: "Fermée depuis le 26 février 2025",
      platform_secure: "Platform 100% azo antoka",
      created_by: "avy amin'ny",
      add_update: "Ampidira vaovao",
      post_update: "Alefa",
      cancel: "Avela",
      anonymous: "Tsy fantatra ny anarana",
      private: "PRIVE",
    },
    en: {
      why: "Why?",
      updates: "Updates",
      participants: "Participants",
      share: "Mobilize people! Your support also comes through sharing:",
      share_facebook: "Share on Facebook",
      share_twitter: "on Twitter",
      share_email: "by Email",
      copy_link: "Copy the link:",
      copied: "Copied!",
      donate_btn: "Donate now",
      raised: "raised with",
      donors: "participants",
      closed: "Campaign closed",
      closed_date: "Closed since February 26, 2025",
      platform_secure: "100% secure platform",
      created_by: "by",
      add_update: "Add update",
      post_update: "Post",
      cancel: "Cancel",
      anonymous: "Anonymous",
      private: "PRIVATE",
    },
  }

  const t = translations[language]

  const campaign = {
    id: id,
    title: "Appel pour Lucie",
    creator: "Famille de Xena la G",
    image: "/medical-help.jpg",
    goal: 139446,
    raised: 139446,
    donors: 2899,
    status: "closed",
    closedDate: "26 février 2025",
    isPrivate: true,
    description:
      "Après toutes ces manifestations de générosité incroyable, nous allons bientôt devoir clôturer cette cagnotte. Une nouvelle asso prend le relais !!! Parce que ce handicap, c'est pour la vie, nous cherchons des entreprises et particuliers prêts à soutenir Lucie financièrement, et/ou à mobiliser leurs réseaux.",
    donations: [
      { id: 1, name: "Ab", amount: 9, date: "07 févr. 2025" },
      { id: 2, name: "Anonymous", amount: 5, date: "06 févr. 2025", isAnonymous: true },
      { id: 3, name: "Monique Dilé", amount: 14, date: "23 févr. 2025" },
      { id: 4, name: "Baya", amount: 20, date: "13 févr. 2025" },
      { id: 5, name: "Aissa", amount: null, date: "08 févr. 2025", isAnonymous: true },
    ],
  }

  const percentage = (campaign.raised / campaign.goal) * 100

  const handleAddUpdate = () => {
    if (newUpdate.trim()) {
      setUpdates([
        {
          id: updates.length + 1,
          author: "Vous",
          date: new Date().toLocaleDateString("fr-FR"),
          content: newUpdate,
          type: "text",
        },
        ...updates,
      ])
      setNewUpdate("")
      setShowUpdateForm(false)
    }
  }

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href)
    alert(t.copied)
  }

  return (
    <div className={`campaign-details-cotizup ${isDark ? "dark-mode" : "light-mode"}`}>
      <div className="campaign-header-cotizup">
        <div className="campaign-image-section">
          <img src={campaign.image || "/placeholder.svg"} alt={campaign.title} className="campaign-main-image" />
          <div className="campaign-creator-badge">
            <div className="creator-avatar"></div>
            <div className="creator-info">
              <h3>{campaign.creator}</h3>
              <p>Lancée le 06 sept. 2023</p>
            </div>
          </div>
        </div>

        <div className="campaign-stats-section">
          <div className="stats-amount">
            <h2 className="big-number">{(campaign.raised / 1000).toFixed(0)} €</h2>
            <p>
              {t.raised} {campaign.donors} {t.donors}
            </p>
          </div>

          <div className={`campaign-status ${campaign.status}`}>
            <span className="lock-icon">🔒</span>
            {campaign.status === "closed" ? (
              <div>
                <p className="status-title">{t.closed}</p>
                <p className="status-date">{t.closed_date}</p>
              </div>
            ) : (
              <p>{t.donate_btn}</p>
            )}
          </div>

          <div className="platform-security">
            <span>🛡️</span>
            <p>{t.platform_secure}</p>
          </div>
        </div>
      </div>

      <div className="campaign-body-cotizup">
        <div className="campaign-main-content">
          <div className="tabs-section">
            <div className="tab active">
              <span className="tab-icon">❓</span>
              <span>{t.why}</span>
            </div>
          </div>

          <div className="description-box">
            <p>{campaign.description}</p>
          </div>

          <div className="contact-info">
            <p>Pour me contacter :</p>
            <p>Instagram @lucie.retail</p>
            <p>Facebook @Lucy Luke</p>
          </div>

          <div className="share-section">
            <h3>💡 {t.share}</h3>
            <div className="share-buttons">
              <button className="share-btn facebook">
                <span>👍</span> {t.share_facebook}
              </button>
              <button className="share-btn twitter">
                <span>𝕏</span> {t.share_twitter}
              </button>
              <button className="share-btn email">
                <span>✉️</span> {t.share_email}
              </button>
            </div>

            <div className="copy-link-section">
              <p>{t.copy_link}</p>
              <div className="link-copy">
                <input type="text" value={window.location.href} readOnly />
                <button onClick={handleCopyLink}>Copier</button>
              </div>
            </div>
          </div>

          <div className="updates-section-cotizup">
            <div className="updates-header">
              <h3>
                {t.updates} <span className="update-count">{updates.length}</span>
              </h3>
              {!campaign.status === "closed" && (
                <button className="add-update-btn" onClick={() => setShowUpdateForm(!showUpdateForm)}>
                  {showUpdateForm ? t.cancel : t.add_update}
                </button>
              )}
            </div>

            {showUpdateForm && (
              <div className="update-form">
                <RichTextEditor value={newUpdate} onChange={setNewUpdate} language={language} />
                <div className="form-actions">
                  <button className="post-btn" onClick={handleAddUpdate}>
                    {t.post_update}
                  </button>
                  <button className="cancel-btn" onClick={() => setShowUpdateForm(false)}>
                    {t.cancel}
                  </button>
                </div>
              </div>
            )}

            <div className="updates-list">
              {updates.map((update) => (
                <div key={update.id} className="update-item-cotizup">
                  <div className="update-header">
                    <strong>{update.author}</strong>
                    <span className="update-date">{update.date}</span>
                  </div>
                  {update.type === "video" ? (
                    <div className="update-video">
                      <iframe src={update.content} frameBorder="0" allowFullScreen></iframe>
                    </div>
                  ) : (
                    <p className="update-content">{update.content}</p>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="participants-section-cotizup">
            <div className="participants-header">
              <h3>{t.participants}</h3>
              <span className="participant-count">Cagnotte clôturée avec {campaign.donors} participants</span>
            </div>

            <div className="donations-tabs">
              <button className="tab-btn active">Plus récents</button>
              <button className="tab-btn">Plus élevés</button>
            </div>

            <div className="donations-list">
              {campaign.donations.map((donation) => (
                <div key={donation.id} className="donation-item">
                  <span className="donation-amount">
                    {donation.isAnonymous ? `${t.private}` : `+ ${donation.amount} €`}
                  </span>
                  <span className="donation-name">
                    {t.created_by} {donation.isAnonymous ? t.anonymous : donation.name}
                  </span>
                  <span className="donation-date">{donation.date}</span>
                </div>
              ))}
              <button className="show-more-btn">Afficher plus de participants</button>
            </div>
          </div>
        </div>

        <aside className="campaign-sidebar-cotizup">
          <button className="donate-btn-side" onClick={() => navigate(`/campaign/${campaign.id}/donate`)}>
            {t.donate_btn}
          </button>
        </aside>
      </div>
    </div>
  )
}
